#
# setupProfile.sh
# This script makes setting up the scripts in the Linux installtion settings much easier.
#
# Assumes that the following files are located in the home directory:
#    * profile
#    * envVarSetter.tcl
#    * setupProfe.sh (this script)
#   this puts the onus of making certain that these files are in the home directory 
#
# These files must be manually copied to the Linx environment. This script's permissions
# must be set to execute after it has been copied. 
#
# (1) From the home directory, type "sudo chmod 777 ~/setupProfileVM.sh; sudo ~/setupProfileVM.sh"
# (3) enter the super-user password when prompted
#
# History:
#    2019.1 - 2019/07/17 - WK - cleanup and optimization - adapted from the VM version of this script
#
echo "Non-VM Version 2019.1"
# copy the profile from the home directory to /etc
cd /etc
sudo cp ~/profile .
#
# copy the environment setting tcl script to /etc
sudo cp ~/envVarSetter.tcl .
# change the permission of the Tcl file so that it will run from the profile when rebooted
sudo chmod 777 envVarSetter.tcl
# the setEnv.sh file must be created in the profile.d directory as it doesn't seem that we are able
# to create this file directly from the tcl script.
sudo touch /etc/profile.d/setEnv.sh
# now this new file must have its permissions changed to run
sudo chmod 777 /etc/profile.d/setEnv.sh
#
# that should take care of the modifications to get things set up
# at this point, the ATP or student must modify the profile script
# and set the variable names to their proper locations
