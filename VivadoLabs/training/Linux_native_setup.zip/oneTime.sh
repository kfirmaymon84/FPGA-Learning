# /etc/profile: system-wide .profile file for the Bourne shell (sh(1))
# and Bourne compatible shells (bash(1), ksh(1), ash(1), ...).
#
# ###################################################################################
#
# oneTime setup for Xilinx Customer Education Linux
#
# Instructions:
#    copy all files from the SVN > trunk > LinuxSupport to the host's training directory
#    from the VM, "cd /media/sf_training; chmod 777 oneTime.sh; ./oneTime.sh"
#
# Description:
#   this script performs one-time setups for the Ubuntu Linux configuration
#
#   see in-line comments regarding the individual tasks
#
# History:
#   2019.1 -  2019/08/16 - tweaks with Ashok, Sekar, Bill
#   2019.1 -  2019/08/14 - first release
#
# ###################################################################################

# set default values for the environment variables
XILINX_PATH_int=/opt/xilinx
PETALINUX_PATH_int=/opt/petalinux
TRAINING_PATH_int=/home/xilinx/training
VERSION_int=2019.1

# copy updated file to /etc/sudoers
echo "Replacing sudoers file in /etc so that users can execute all programs as super user without having to enter the pw each time"
sudo cp /media/sf_training/sudoers /etc/sudoers

# update all applications
echo "todo: update all applications"

# disable the Linux software updater 
echo "disable the Linux software updater"
sudo systemctl disable apt-daily.service apt-daily-upgrade.service
sudo systemctl disable apt-daily.timer apt-daily-upgrade.timer

# install the Xilinx tools
echo "todo: install the Xilinx tools"


# uninstall the xic annoyance (move to one-time setup?)
echo "uninstalling xic"
if [ -d $XILINX_PATH_int/.xinstall/xic/ ]
then
   $XILINX_PATH_int/.xinstall/xic/xsetup -b Uninstall
fi

# is java installed? todo: make this generic and not tied to a specific version
echo "installing Java"
if [ -d /etc/java-11-openjdk ]
then
   echo "Java already installed - no action required"
else
   echo xilinx | sudo apt update
   echo xilinx | sudo apt install default-jre
fi

# install the diffuse tool
echo "installing the diffuse tool"
echo xilinx | sudo apt-get install diffuse

# update the profiler
echo "updating the profiler and configuring the assciated files"
echo xilinx | sudo chmod 777 /media/sf_training/setupProfileVM.sh
/media/sf_training/setupProfileVM.sh

# Copy the xsct.desktop file from /media/sf_training/ to /usr/share/applications
echo "copying the xsct desktop and icon..."
sudo cp /media/sf_training/xsct.desktop /usr/share/applications/
cp /media/sf_training/xsct_logo.png $SDK_PATH/doc/xsct_logo.png

# there are a few things that we can't do in the script that maybe we will be able to do in a future version
echo "___ add XSCT to the taskbar"
echo "___ add diffuse to the taskbar"



echo "### DONE ###"
